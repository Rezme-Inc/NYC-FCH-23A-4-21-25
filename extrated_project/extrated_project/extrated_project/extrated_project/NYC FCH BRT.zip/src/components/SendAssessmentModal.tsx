import React, { useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { Modal } from './ui-kit/Modal';
import { Input } from './ui-kit/Input';
import { Button } from './ui-kit/Button';
import { CheckCircle, Loader } from 'lucide-react';

const WORKDAY_URL = 'https://marketplace.workday.com/en-US/pages/partner-profile?vendor=6f0bc3ee-3c5e-4241-8861-104cabc8278f';

interface FormData {
  recipientEmail: string;
}

interface SendAssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  handlePreview: (data: { recipientEmail: string }) => void;
}

const ThankYouMessage: React.FC<{ onClose: () => void }> = React.memo(({ onClose }) => (
  <div className="flex flex-col items-center py-16 px-8 text-center">
    <CheckCircle className="w-12 h-12 text-green-500 mb-5" />

    <h2 className="text-3xl font-semibold mb-4">Thank You!</h2>

    <p className="text-base leading-relaxed max-w-xl mb-6">
      Thank you for completing the individualized assessment and sharing in
      the creation of technology to strengthen communities and increase
      labor‑market participation. Your participation reflects a shared belief
      that when all individuals can contribute to the labor market,
      America&#39;s economic competitiveness grows stronger.
    </p>

    <p className="text-base leading-relaxed max-w-xl">
      To learn more, please visit our&nbsp;
      <a
        href={WORKDAY_URL}
        className="text-blue-600 underline font-medium"
        target="_blank"
        rel="noopener noreferrer"
      >
        Enterprise Workday Integration Solution
      </a>.
    </p>

    <button
      onClick={onClose}
      className="mt-10 px-6 py-3 bg-blue-700 text-white rounded-lg font-medium
                 shadow hover:bg-blue-800 focus:outline-none focus:ring"
    >
      Close
    </button>
  </div>
));

ThankYouMessage.displayName = 'ThankYouMessage';

export const SendAssessmentModal: React.FC<SendAssessmentModalProps> = ({
  isOpen,
  onClose,
  handlePreview,
}) => {
  const [isSuccess, setIsSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { isValid }
  } = useForm<FormData>({
    mode: 'onChange'
  });

  const handleClose = useCallback(() => {
    setIsSuccess(false);
    setError(null);
    onClose();
  }, [onClose]);

  const onSubmit = useCallback(async (data: FormData) => {
    setIsSubmitting(true);
    setError(null);
    
    try {
      await handlePreview(data);
      setIsSuccess(true);
      reset();
    } catch (error) {
      setError('Failed to send assessment. Please try again.');
      console.error('Failed to send assessment:', error);
    } finally {
      setIsSubmitting(false);
    }
  }, [handlePreview, reset]);

  // Reset states when modal is opened
  React.useEffect(() => {
    if (isOpen) {
      setIsSuccess(false);
      setError(null);
      reset();
    }
  }, [isOpen, reset]);

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title={isSuccess ? "" : "Send Assessment Results"}>
      {!isSuccess ? (
        <form onSubmit={handleSubmit(onSubmit)} className="p-6">
          <div className="space-y-4">
            <div>
              <Input
                label="Recipient Email"
                type="email"
                {...register('recipientEmail')}
                placeholder="Enter recipient's email address"
                disabled={isSubmitting}
              />
              {error && (
                <p className="mt-2 text-sm text-red-600">{error}</p>
              )}
            </div>
          </div>
          <div className="mt-6 flex justify-end space-x-3">
            <Button
              variant="secondary"
              onClick={handleClose}
              className="px-4 py-2"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              className="px-4 py-2 min-w-[80px]"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <Loader className="w-5 h-5 animate-spin" />
              ) : (
                'Send'
              )}
            </Button>
          </div>
        </form>
      ) : (
        <ThankYouMessage onClose={handleClose} />
      )}
    </Modal>
  );
}; 