declare module '*.pdf' {
    const content: string;
    export default content;
} 